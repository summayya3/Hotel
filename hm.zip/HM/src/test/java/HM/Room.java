/*
 * Copyright 2017 Faculty of Informatics, University of Debrecen.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package HM;

import com.mycompany.hm.FXMLRoomController;
import java.lang.reflect.Field;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.junit.Assert;
import org.junit.Test;

/**
 *
 * @author sumee_000
 */
public class Room {

    public Room() {
    }

    @Test
    public void addRoom() throws IllegalArgumentException {
        FXMLRoomController test = new FXMLRoomController();
        Class a;
        a = test.getClass();

        
        try {
            Field f;
            f = a.getDeclaredField("field");
            Object o = null;
            f.get(o);
            String s = (String) o;

            Field f2;
            f2 = a.getDeclaredField("field2");
            Object o2=null;
            f2.get(o2);
            String s2 = (String) o2;

            Field f3;
            f3 = a.getDeclaredField("field3");
            Object o3=null;
            f3.get(o3);
            String s3 = (String) o3;

            Field f4;
            f4 = a.getDeclaredField("field");
            Object o4=null;
            f4.get(o4);
            String s4 = (String) o4;

            Assert.assertFalse(s, equals(null));
            Assert.assertEquals(s2, s2);
            Assert.assertEquals(s3, s3);
            Assert.assertEquals(s4, s4);

        } catch (NoSuchFieldException ex) {
            Logger.getLogger(Room.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SecurityException ex) {
            Logger.getLogger(Room.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            Logger.getLogger(Room.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    // @Test
    // public void hello() {}
}
