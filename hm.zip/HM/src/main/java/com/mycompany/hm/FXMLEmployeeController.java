/*
 * Copyright 2017 Faculty of Informatics, University of Debrecen.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.mycompany.hm;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author sumee_000
 */
public class FXMLEmployeeController implements Initializable {

    @FXML
    private TextField EN;
    @FXML
    private TextField EP;
    @FXML
    private TextField ER;
    @FXML
    private TextField GENDER;
    @FXML
    private TextField AGE;
    @FXML
    private TableColumn<employee, String> C1;
    private TableColumn<employee, String> C2;
    @FXML
    private TableColumn<employee, Integer> C3;
    @FXML
    private TableColumn<employee, String> C4;
    @FXML
    private TableView<?> tmodel;
    @FXML
    private TableColumn<employee, Integer> C5;

    private ObservableList table;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

    /**
     * The action button below adds employee data to the database and can be
     * accessed through the link with username and password
     *
     * @param event
     */
    @FXML
    private void add(ActionEvent event) throws ClassNotFoundException, InstantiationException, IllegalAccessException {
        String d = EN.getText();
        String sa = EP.getText();
        int yi = Integer.parseInt(ER.getText());
        int we = Integer.parseInt(AGE.getText());
        String rw = GENDER.getText();

        try {
            DriverManager.registerDriver((Driver) (DriverManager) Class.forName("org.derby.jdbc.ClientDriver").newInstance());
            Connection conn = DriverManager.getConnection("jdbc:derby://localhost:1527/sumy", "ENG_GQEPGP", "kassai");
            java.sql.Statement st = conn.createStatement();

            String s = "Insert into Employees(EMPLOYEE_NAME,EMPLOYEE_POSITION,EMPLOYEE_RATE,AGE,GENDER) values('" + EN.getText() + "','" + EP.getText() + "','" + yi + "','" + we + "','" + GENDER.getText() + "')";

            st.executeUpdate(s);
            JOptionPane.showMessageDialog(null, "Employee Added");

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Incorrect!\nTry again");
        }
    }

    /**
     * The action button below updates employee data to the database and can be
     * accessed through the link with username and password
     *
     * @param event
     */
    @FXML
    private void update(ActionEvent event) throws ClassNotFoundException, InstantiationException, IllegalAccessException {
        try {
            String n = EN.getText();
            String p = EP.getText();
            int r = Integer.parseInt(ER.getText());
            String a = AGE.getText();
            int g = Integer.parseInt(GENDER.getText());

            DriverManager.registerDriver((Driver) (DriverManager) Class.forName("org.derby.jdbc.ClientDriver").newInstance());
            Connection con = DriverManager.getConnection("jdbc:derby://localhost:1527/sumy", "ENG_GQEPGP", "kassai");
            java.sql.Statement st = con.createStatement();

            st = con.createStatement();
            {

                String s = "Update EMPLOYEES set EMPLOYEE_NAME = '" + EN.getText() + "', EMPLOYEE_POSITION = '" + EP.getText() + "' , EMPLOYEE_RATE = '" + r + "' , AGE = '" + AGE.getText() + "'where (GENDER = '" + g + "')";

                st.execute(s);

                st.close();
                con.close();
            }

        } catch (SQLException ex) {
            Logger.getLogger(FXMLEmployeeController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * The action button below shows all the employee data on a table in the
     * database and can be accessed through the link with username and password
     *
     * @param event
     */
    @FXML
    private void Showdetails(ActionEvent event) throws ClassNotFoundException, InstantiationException, IllegalAccessException {
        try {
            DriverManager.registerDriver((Driver) (DriverManager) Class.forName("org.derby.jdbc.ClientDriver").newInstance());
            Connection con = DriverManager.getConnection("jdbc:derby://localhost:1527/sumy", "ENG_GQEPGP", "kassai");
            java.sql.Statement st = con.createStatement();

            table = FXCollections.observableArrayList();
            String s;
            s = "Select * from EMPLOYEE ";

            ResultSet r;
            r = st.executeQuery(s);

            while (r.next()) {
                table.add(new employee(r.getString("EN"), r.getString("EP"), r.getInt("ER"), r.getString("GENDER"), r.getInt("AGE")));
            }

            r.close();
            st.close();
            con.close();

        } catch (SQLException ex) {
            Logger.getLogger(FXMLEmployeeController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * The action button below deletes employee data to the database and can be
     * accessed through the link with username and password
     *
     * @param event
     */
    @FXML
    private void delete(ActionEvent event) throws ClassNotFoundException, InstantiationException, IllegalAccessException {
        String dd = EN.getText();
        String aa = EP.getText();

        try {
            DriverManager.registerDriver((Driver) (DriverManager) Class.forName("org.derby.jdbc.ClientDriver").newInstance());
            Connection con = DriverManager.getConnection("jdbc:derby://localhost:1527/sumy", "ENG_GQEPGP", "kassai");
            java.sql.Statement st = con.createStatement();
            {
                String s = "Delete Employees(EMPLOYEE_NAME,EMPLOYEE_POSITION,) values('" + EN.getText() + "','" + EP.getText() + "')";
                st.execute(s);

                st.close();
                con.close();

            }

        } catch (SQLException ex) {
            Logger.getLogger(FXMLEmployeeController.class
                    .getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * The action button below takes you back to the old scene
     *
     * @param event
     */
    @FXML
    private void Backscene(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("/fxml/FXMLRoom.fxml"));
        Scene scene = new Scene(root);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.hide();
        stage.setScene(scene);
        stage.show();

    }

}
