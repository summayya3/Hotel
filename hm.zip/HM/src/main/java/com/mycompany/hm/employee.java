/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.hm;

import javafx.beans.property.StringProperty;

/**
 *
 * @author sumee_000
 */
public class employee {

    private final String EN;
    private final String EP;
    private final Integer ER;
    private final Integer AGE;
    private final String GENDER;

    public employee(String EN, String EP, Integer ER, String GENDER,Integer AGE) {
        this.EN = EN;
        this.EP = EP;
        this.ER = ER;
        this.AGE = AGE;
        this.GENDER = GENDER;
    }

    public String getEN() {
        return EN;
    }

    public String getEP() {
        return EP;
    }

    public Integer getER() {
        return ER;
    }

    public Integer getAGE() {
        return AGE;
    }

    public String getGENDER() {
        return GENDER;
    }

   
}


