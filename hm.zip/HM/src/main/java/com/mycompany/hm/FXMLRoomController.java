/*
 * Copyright 2017 Faculty of Informatics, University of Debrecen.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.mycompany.hm;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author sumee_000
 */
public class FXMLRoomController implements Initializable {

    @FXML
    private TextField RN;
    @FXML
    private TextField RT;
    @FXML
    private TextField RR;
    @FXML
    private TextField RD;
    @FXML
    private TableColumn<room, Integer> C1;
    @FXML
    private TableColumn<room, String> C2;
    @FXML
    private TableColumn<room, Integer> C3;
    @FXML
    private TableColumn<room, String> C4;
    @FXML
    private TableView<room> tmodel;

    private ObservableList table;

    /*@FXML
    private TableView tmodel;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

    /**
     * The action button below adds room data to the database and can be
     * accessed through the link with username and password
     *
     * @param event
     */
    @FXML
    private void Add(ActionEvent event) throws ClassNotFoundException, InstantiationException, IllegalAccessException {
        int a = Integer.parseInt(RN.getText());
        String b = RT.getText();
        int c = Integer.parseInt(RR.getText());
        String d = RD.getText();

        try {
            DriverManager.registerDriver((Driver) (DriverManager) Class.forName("org.derby.jdbc.ClientDriver").newInstance());
            Connection conn = DriverManager.getConnection("jdbc:derby://localhost:1527/sumy", "ENG_GQEPGP", "kassai");
            java.sql.Statement st = conn.createStatement();
            String s = "Insert into Rooms(ROOM_NUMBER,ROOM_TYPE,ROOM_RATE,ROOM_DESCRIPTION) values('" + RN.getText() + "','" + RT.getText() + "','" + RR.getText() + "','" + RD.getText() + "')";

            st.executeUpdate(s);
            JOptionPane.showMessageDialog(null, "Room Added");

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Incorrect!\nTry again");
        }
    }

    /**
     * The action button below shows details about the room on a table the
     * database and can be accessed through the link with username and password
     *
     * @param event
     */
    @FXML
    private void ShowDetails(ActionEvent event) throws ClassNotFoundException, InstantiationException, IllegalAccessException {

        try {
            DriverManager.registerDriver((Driver) (DriverManager) Class.forName("org.derby.jdbc.ClientDriver").newInstance());
            Connection conn = DriverManager.getConnection("jdbc:derby://localhost:1527/sumy", "ENG_GQEPGP", "kassai");
            java.sql.Statement st = conn.createStatement();
            table = FXCollections.observableArrayList();
            String s;
            s = "Select * from ROOMS ";

            ResultSet r;
            r = st.executeQuery(s);
            while (r.next()) {
                table.add(new room(r.getInt("RN"), r.getString("RT"), r.getInt("RR"), r.getString("RD")));
            }

        } catch (SQLException ex) {
            Logger.getLogger(FXMLRoomController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * The action button below goes to the next scene
     *
     * @param event
     */
    @FXML
    private void NextScene(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("/fxml/FXMLEmployee.fxml"));
        Scene scene = new Scene(root);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.hide();
        stage.setScene(scene);
        stage.show();
    }

    /**
     * The action button below updates room data on the table to the database
     * and can be accessed through the link with username and password
     *
     * @param event
     */
    @FXML
    private void Update(ActionEvent event) throws ClassNotFoundException, InstantiationException, IllegalAccessException {
        try {
            int a = Integer.parseInt(RN.getText());
            String b = RT.getText();
            int c = Integer.parseInt(RR.getText());
            String d = RD.getText();

            DriverManager.registerDriver((Driver) (DriverManager) Class.forName("org.derby.jdbc.ClientDriver").newInstance());
            Connection con = DriverManager.getConnection("jdbc:derby://localhost:1527/sumy", "ENG_GQEPGP", "kassai");
            java.sql.Statement st = con.createStatement();

            {

                String s = "Update Room set ROOM_NUMBER = '" + RN.getText() + "', ROOM_TYPE = '" + RT.getText() + "' , ROOM_RATE = '" + RR.getText() + "',where (ROOM_DESCRIPTION = '" + RD.getText() + "')";

                st.execute(s);

                st.close();
                con.close();
            }

        } catch (SQLException ex) {
            Logger.getLogger(FXMLRoomController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * The action button below deletes room data to the database and can be
     * accessed through the link with username and password
     *
     * @param event
     */
    @FXML
    private void Delete(ActionEvent event) throws ClassNotFoundException, InstantiationException, IllegalAccessException {

        int nm = Integer.parseInt(RN.getText());

        try {
            DriverManager.registerDriver((Driver) (DriverManager) Class.forName("org.derby.jdbc.ClientDriver").newInstance());
            Connection con = DriverManager.getConnection("jdbc:derby://localhost:1527/sumy", "ENG_GQEPGP", "kassai");
            java.sql.Statement st = con.createStatement();
            {
                String s = "Delete room (ROOM_NUMBER = '" + nm + "') ";
                st.executeUpdate(s);

                st.close();
                con.close();
            }

        } catch (SQLException ex) {
            Logger.getLogger(FXMLRoomController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
