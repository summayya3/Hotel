/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.hm;

import javafx.beans.property.StringProperty;

/**
 *
 * @author sumee_000
 */
public class room {

    private final Integer RN;
    private final String RT;
    private final Integer RR;
    private final String RD;

    public room(Integer RN, String RT, Integer RR, String RD) {
        this.RN = RN;
        this.RT = RT;
        this.RR = RR;
        this.RD = RD;

    }

    public Integer getRN() {
        return RN;
    }

    public String getRT() {
        return RT;
    }

    public Integer getRR() {
        return RR;
    }

    public String getRD() {
        return RD;
       
    }

}
